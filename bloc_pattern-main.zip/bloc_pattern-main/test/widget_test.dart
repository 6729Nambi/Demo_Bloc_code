import 'package:bloc_example/domain/bloc/counter_bloc/counter_bloc.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('Counter', () {
    test('value should start at 0', () {
      expect(CounterBloc().state, 0);
    });

    test('value should be incremented', () {
      final counter = CounterBloc();

      counter.increment();

      expect(counter.state, 1);
    });

    test('value should be decremented', () {
      final counter = CounterBloc();

      counter.decrement();

      expect(counter.state, -1);
    });
  });
}
