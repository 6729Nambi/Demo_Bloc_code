import 'package:bloc_example/main.dart' as app;
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';

/// Code to run integration test
/// flutter test integration_test/widget_test.dart

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  /// sometime we need to init this way to insure app fully initialized
  // final binding = IntegrationTestWidgetsFlutterBinding.ensureInitialized();
  // binding.framePolicy = LiveTestWidgetsFlutterBindingFramePolicy.fullyLive;

  setUpAll(() {
    /// We can init stuff here if required
  });

  group('end-to-end test', () {
    testWidgets('test counter', (tester) async {
      // Init app
      await app.main();

      // Trigger a frame.
      await tester.pumpAndSettle();

      // Verify the counter starts at 0.
      expect(find.text('0'), findsOneWidget);

      // increment
      final button = find.byKey(const Key('button'));
      await tester.tap(button);

      // Trigger a frame.
      await tester.pumpAndSettle();

      // Verify the counter increments by 1.
      expect(find.text('1'), findsOneWidget);

      // photo screen button
      final photoScreenButton = find.byKey(const Key('photo_screen_button'));
      await tester.tap(photoScreenButton);

      // Trigger a frame.
      await tester.pumpAndSettle();

      // find grid view
      final listView = find.byKey(const Key('photo_grid_view'));

      // test find grid view
      expect(listView, isNotNull);

      await Future.delayed(const Duration(seconds: 5));
    });
  });
}
