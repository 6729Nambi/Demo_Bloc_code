# bloc_example

In this project we have covered bloc for state management and get_it for dependency injection,
Used packages like auto_route, retrofit to generate route, API with single command

Firebase crashlytics, analytics and remote config added We can monitor app with more accuracy
can also do AB testing with all this firebase integration

We did crypt important files that contain important data like API keys, JKS etc, And can be
decrypt with private key which we can provide authorised developer

Added unit test and integration test

We have also implemented CI/CD with github actions, App will auto test and build for both
Android and iOS on push or pull request before merge so we can have idea about breaking 
code before merge

API key Pexels (key may expire in that case generate new key from Pexels)
key - 563492ad6f91700001000001c0a0438f3a314e0a9d6378b8ed8f1b59 
doc - https://www.pexels.com/api/documentation/

# Code Overview

State Management: Bloc

Plugins Usage:

    auto_route
    retrofit
    bloc
    get_it
    dio

File Structure:

--- lib --- |
            |
            |(Config, Util functions etc.. )
            |--- core
            |
            |(Responsible for exchange of data )
            |--- data -------------|
            |                      |--- local
            |                      |--- model
            |                      |--- remote
            |                      |--- repository
            |
            |(Computation Logic, models, extensions etc.)
            |--- domain -----------|
            |                      |--- bloc (different blocs) ---|  
            |                                                     | --- state  
            |                                                     | --- bloc  
            |
            |(Get data from api or local DB)
            |--- infrastructure ---|
            |                      |--- api_core
            |                      |--- db_core
            |                      |--- photo_api
            |
            |(UI, View models, SharedWidgets and Themes)
            |--- presentation

## Getting Started

1. Clone this repository. 
2. run below command to create all generated files like, model classes, routers, retrofit classes
   flutter pub run build_runner build --delete-conflicting-outputs
3. `flutter pub get`, `cd iOS`, `pod install`
4. `flutter run` 
