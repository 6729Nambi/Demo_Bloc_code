abstract class HeavyTaskState {}

class HeavyTaskInitState extends HeavyTaskState {}

class HeavyTaskLoadedState extends HeavyTaskState {
  final int count;
  HeavyTaskLoadedState(this.count);
}
