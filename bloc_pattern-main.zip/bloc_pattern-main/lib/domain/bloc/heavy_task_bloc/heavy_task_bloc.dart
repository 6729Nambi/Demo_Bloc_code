import 'package:bloc_example/data/repository/heavy_task_repository.dart';
import 'package:bloc_example/domain/bloc/counter_bloc/counter_bloc.dart';
import 'package:bloc_example/domain/bloc/heavy_task_bloc/heavy_task_state.dart';
import 'package:bloc_example/injector.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class HeavyTaskBloc extends Cubit<HeavyTaskState> {
  final HeavyTaskRepository _heavyTaskRepository;

  HeavyTaskBloc(this._heavyTaskRepository) : super(HeavyTaskInitState());

  Future<void> initHeavyTaskBloc() async {
    // We need to first pass Init and then other event cause if
    // same event pass it will not pass second one
    emit(HeavyTaskInitState());
    await Future.delayed(const Duration(seconds: 2));
    emit(HeavyTaskLoadedState(_heavyTaskRepository.getInitData()));
  }

  void increaseCount() {
    getIt<CounterBloc>().increment();
    emit(HeavyTaskLoadedState(getIt<CounterBloc>().state));
  }

  void decreaseCount() {
    getIt<CounterBloc>().decrement();
    emit(HeavyTaskLoadedState(getIt<CounterBloc>().state));
  }
}
