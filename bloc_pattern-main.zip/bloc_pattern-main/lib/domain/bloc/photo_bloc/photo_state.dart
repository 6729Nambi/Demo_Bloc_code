import 'package:bloc_example/data/model/album.dart';

abstract class PhotoState {}

class PhotoInitState extends PhotoState {}

class PhotoLoadedState extends PhotoState {
  final List<Photo> photos;
  PhotoLoadedState(this.photos);
}

class PhotoErrorState extends PhotoState {
  final String errorMessage;
  PhotoErrorState(this.errorMessage);
}
