import 'package:bloc_example/data/model/album.dart';
import 'package:bloc_example/data/repository/photo_repository.dart';
import 'package:bloc_example/domain/bloc/photo_bloc/photo_state.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class PhotoBloc extends Cubit<PhotoState> {
  final PhotoRepository _photoRepository;

  PhotoBloc(this._photoRepository) : super(PhotoInitState());

  final List<Photo> _photos = [];

  Future<void> getPhotoWithQuery({bool isFirstTime = false}) async {
    final response = await _photoRepository.getPhotoWithQuery('flower');
    if (response.isSuccess) {
      if (isFirstTime) {
        emit(PhotoInitState());
        _photos.clear();
      }
      _photos.addAll(response.data.photos);
      emit(PhotoLoadedState(_photos));
    } else {
      emit(PhotoErrorState(response.error));
    }
  }
}
