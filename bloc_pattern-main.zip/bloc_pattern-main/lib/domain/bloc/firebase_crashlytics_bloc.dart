import 'package:bloc_example/core/util/app_config.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';

class FirebaseCrashlyticsBloc {
  final FirebaseCrashlytics _crashlytics = FirebaseCrashlytics.instance;

  Future<void> logCrash(dynamic exception, StackTrace? stack) async {
    /// If firebase crashlytics is off return from here
    if (!AppConfig.isFirebaseCrashlyticsOn) return;

    _crashlytics.recordError(
      exception,
      stack,
      fatal: true,
    );
  }
}
