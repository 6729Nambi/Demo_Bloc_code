import 'package:bloc_example/injector.dart';
import 'package:firebase_remote_config/firebase_remote_config.dart';

import 'firebase_crashlytics_bloc.dart';

class FirebaseRemoteConfigBloc {
  late final FirebaseRemoteConfig remoteConfig;
  Future<void> init() async {
    try {
      remoteConfig = FirebaseRemoteConfig.instance;
      await remoteConfig.setConfigSettings(RemoteConfigSettings(
        fetchTimeout: const Duration(seconds: 10),
        minimumFetchInterval: const Duration(seconds: 0),
      ));
      await remoteConfig.setDefaults(<String, dynamic>{
        'button_side': 'right',
      });

      /// Make sure you call fetchAndActivate sometimes fetch() not working
      await remoteConfig.fetchAndActivate();
    } catch (e, stack) {
      getIt<FirebaseCrashlyticsBloc>().logCrash(e, stack);
    }
  }

  bool getButtonSide() => remoteConfig.getString('button_side') == 'left';
}
