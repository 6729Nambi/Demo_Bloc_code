import 'dart:developer';

import 'package:bloc_example/core/util/app_config.dart';
import 'package:bloc_example/core/util_function.dart';
import 'package:firebase_analytics/firebase_analytics.dart';

class FirebaseAnalyticBloc {
  final FirebaseAnalytics _analytics = FirebaseAnalytics.instance;

  // log event we are using substring cause of firebase restriction
  // in bot value and params
  // https://firebase.google.com/docs/reference/android/com/google/firebase/analytics/FirebaseAnalytics#public-void-logevent-string-name,-bundle-params
  // https://stackoverflow.com/a/38473867
  Future<void> logEvent({
    required String name,
    Map<String, dynamic>? parameters,
  }) async {
    /// If firebase analytic is off return from here
    if (!AppConfig.isFirebaseAnalyticOn) return;

    try {
      await _analytics.logEvent(
        name: UtilFunction.subString(name, 0, 39),
        parameters: parameters == null ? null : _filterOutNulls(parameters),
      );
    } catch (error, stacktrace) {
      log("Error : $error \n Stack : $stacktrace");
    }
    return Future.value(null);
  }

  /// Creates a new map containing all of the key/value pairs from [parameters]
  /// except those whose value is `null`.
  Map<String, dynamic> _filterOutNulls(Map<String, dynamic> parameters) {
    final Map<String, dynamic> filtered = <String, dynamic>{};
    parameters.forEach((String key, dynamic value) {
      if (value != null) {
        if (value is String) {
          value = UtilFunction.subString(value, 0, 99);
        }
        filtered[UtilFunction.subString(key, 0, 39)] = value;
      }
    });
    return filtered;
  }
}
