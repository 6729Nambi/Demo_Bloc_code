import 'package:get_it/get_it.dart';

import 'data/local/heavy_task_local_data.dart';
import 'data/local/photo_local_data.dart';
import 'data/remote/heavy_task_remote_data.dart';
import 'data/remote/photo_remote_data.dart';
import 'data/repository/heavy_task_repository.dart';
import 'data/repository/photo_repository.dart';
import 'domain/bloc/counter_bloc/counter_bloc.dart';
import 'domain/bloc/firebase_analytic_bloc.dart';
import 'domain/bloc/firebase_crashlytics_bloc.dart';
import 'domain/bloc/firebase_remote_config_bloc.dart';
import 'domain/bloc/heavy_task_bloc/heavy_task_bloc.dart';
import 'domain/bloc/photo_bloc/photo_bloc.dart';

final getIt = GetIt.instance;

void getItInit() {
  /// services
  // Heavy task screen photo
  getIt.registerSingleton<HeavyTaskLocalData>(HeavyTaskLocalData());
  getIt.registerSingleton<HeavyTaskRemoteData>(HeavyTaskRemoteData());
  // Photo screen photo
  getIt.registerSingleton<PhotoRemoteData>(PhotoRemoteData());
  getIt.registerSingleton<PhotoLocalData>(PhotoLocalData());

  /// Repository
  // Heavy task screen repository
  getIt.registerSingleton<HeavyTaskRepository>(
    HeavyTaskRepository(getIt(), getIt()),
  );
  // Photo screen repository
  getIt.registerSingleton<PhotoRepository>(
    PhotoRepository(getIt(), getIt()),
  );

  /// Bloc
  // MainScreen bloc
  getIt.registerSingleton<CounterBloc>(CounterBloc());
  // Heavy Task screen bloc
  getIt.registerSingleton<HeavyTaskBloc>(HeavyTaskBloc(getIt()));
  // Photo screen bloc
  getIt.registerSingleton<PhotoBloc>(PhotoBloc(getIt()));
  getIt.registerSingleton<FirebaseAnalyticBloc>(FirebaseAnalyticBloc());
  getIt.registerSingleton<FirebaseCrashlyticsBloc>(FirebaseCrashlyticsBloc());
  getIt.registerSingleton<FirebaseRemoteConfigBloc>(FirebaseRemoteConfigBloc());
}
