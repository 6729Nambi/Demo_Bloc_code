import 'dart:async';
import 'dart:developer';

import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart';
import 'package:flutter/material.dart';

import 'domain/bloc/firebase_remote_config_bloc.dart';
import 'firebase_options.dart';
import 'injector.dart';
import 'presentation/route_config/app_router.gr.dart';

Future<void> main() async {
  /// App entry point
  runZonedGuarded<Future<void>>(
    () async {
      WidgetsFlutterBinding.ensureInitialized();

      await Firebase.initializeApp(
        options: DefaultFirebaseOptions.currentPlatform,
      );

      FlutterError.onError =
          FirebaseCrashlytics.instance.recordFlutterFatalError;

      /// Init get-it
      getItInit();

      /// wait until we get remote config data
      await getIt<FirebaseRemoteConfigBloc>().init();

      runApp(
        MyApp(),
      );
    },
    (error, stack) {
      log("error main-> $error \n $stack");
      FirebaseCrashlytics.instance.recordError(
        error,
        stack,
        fatal: true,
      );
    },
  );
}

class MyApp extends StatelessWidget {
  MyApp({Key? key}) : super(key: key);

  final _appRouter = AppRouter();

  static FirebaseAnalytics analytics = FirebaseAnalytics.instance;
  static FirebaseAnalyticsObserver observer =
      FirebaseAnalyticsObserver(analytics: analytics);

  // This widget is the root of your domain.
  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'Bloc Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      routerDelegate: _appRouter.delegate(
        navigatorObservers: () => <NavigatorObserver>[observer],
      ),
      routeInformationParser: _appRouter.defaultRouteParser(),
    );
  }
}
