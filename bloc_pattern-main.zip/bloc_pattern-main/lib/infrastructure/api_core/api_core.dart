import 'dart:developer';
import 'dart:io';

import 'package:bloc_example/core/util/alert_message.dart';
import 'package:bloc_example/core/util/app_config.dart';
import 'package:bloc_example/infrastructure/api_core/result.dart';
import 'package:dio/dio.dart';
import 'package:flutter/widgets.dart';

typedef EntityMapper<Entity, Model> = Model Function(Entity entity);

abstract class _ErrorCode {
  static const message = "message";
  static const error = "error";
}

abstract class ApiCore {
  final String _apiEndpoint = AppConfig.BASE_URL;
  final String _token = AppConfig.TOKEN;

  Future<Map<String, String>> _getHeaders() async {
    return {
      HttpHeaders.acceptHeader: "domain/json",
      HttpHeaders.contentTypeHeader: "domain/json",
      HttpHeaders.authorizationHeader: "Bearer $_token"
    };
  }

  Future<Dio> get dio => _getDio();

  Future<Dio> _getDio() async {
    final dio = Dio();
    final headers = await _getHeaders();
    dio.options = BaseOptions(
      baseUrl: _apiEndpoint,
      connectTimeout: 20000,
      receiveTimeout: 20000,
      headers: headers,
      followRedirects: false,
    );
    dio.interceptors.add(LogInterceptor(
        responseBody: true,
        requestBody: true,
        responseHeader: false,
        requestHeader: true,
        logPrint: (object) => debugPrint(object.toString()),
        request: true));
    return dio;
  }

  Future<Result<T>> safeCall<T>(Future<T> call) async {
    try {
      var response = await call;
      log('Base Repository: API successful!');
      return Success(response);
    } catch (exception, stackTrace) {
      log('Base Repository: API failure --> $exception');
      log('Base Repository: API stacktrace --> $stackTrace');
      if (exception is DioError) {
        switch (exception.type) {
          case DioErrorType.connectTimeout:
          case DioErrorType.sendTimeout:
          case DioErrorType.receiveTimeout:
          case DioErrorType.cancel:
            return Error(AlertMessages.TIMEOUT_ERROR_MSG);

          case DioErrorType.other:
            return Error(AlertMessages.OFFLINE_ERROR_MSG);

          case DioErrorType.response:
            return await _getError(exception.response);

          default:
            return await _getError(exception.response);
        }
      }
      return Error(AlertMessages.GENERIC_ERROR_MSG);
    }
  }

  Future<Result<T>> _getError<T>(Response? response) async {
    log("response in error case : ${response?.data}");
    if (response?.data != null && response?.data is Map<String, dynamic>) {
      log("response in error case 000: ${response?.data}");
      if ((response!.data as Map<String, dynamic>)
          .containsKey(_ErrorCode.message)) {
        var errorMessage = response.data[_ErrorCode.message] as String;
        log("response in error case 111: $errorMessage");
        return Error(errorMessage);
      }
      if ((response.data as Map<String, dynamic>).isNotEmpty) {
        log("Api error response -> ${response.data.toString()}");
        var errorMessage = response.data[_ErrorCode.error] as String;
        return Error(errorMessage);
      }
    }
    return Error(
      AlertMessages.GENERIC_ERROR_MSG,
    );
  }
}
