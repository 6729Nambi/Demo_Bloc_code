import 'package:bloc_example/data/model/album.dart';
import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';

part 'photo_api.g.dart';

@RestApi()
abstract class PhotoApi {
  factory PhotoApi(Dio dio) = _PhotoApi;

  @GET("search")
  Future<Album> getPhotoWithQuery(
    @Header("Content-Type") String contentType,
    @Query("query") String query,
    @Body() Map<String, dynamic> data,
  );
}
