import 'dart:math';

class UtilFunction {
  static String subString(String? string, int start, int end) {
    if (isNullOrEmpty(string)) return "";

    end = min(string!.length, end);
    return string.substring(start, end);
  }

  static bool isNullOrEmpty(String? text) {
    return !isNotNullOrEmpty(text);
  }

  static bool isNotNullOrEmpty(String? text) {
    return text != null && text.isNotEmpty;
  }
}
