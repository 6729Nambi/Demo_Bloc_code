class AppConfig {
  static const HOST = 'https://api.pexels.com/v1/';
  static const String TOKEN =
      '563492ad6f91700001000001c0a0438f3a314e0a9d6378b8ed8f1b59';
  static const String BASE_URL = '$HOST';

  /// App config

  static bool isFirebaseCrashlyticsOn = true;
  static bool isFirebaseAnalyticOn = true;
}
