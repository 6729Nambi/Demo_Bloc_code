class PhotoLocalData {}
