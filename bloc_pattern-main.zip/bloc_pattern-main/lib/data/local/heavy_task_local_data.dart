class HeavyTaskLocalData {
  int getInitData() {
    return 110;
  }
}
