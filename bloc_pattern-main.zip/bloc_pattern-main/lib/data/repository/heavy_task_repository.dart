import 'package:bloc_example/data/local/heavy_task_local_data.dart';
import 'package:bloc_example/data/remote/heavy_task_remote_data.dart';

class HeavyTaskRepository {
  final HeavyTaskLocalData _heavyTaskLocalData;
  final HeavyTaskRemoteData _heavyTaskRemoteData;
  HeavyTaskRepository(this._heavyTaskLocalData, this._heavyTaskRemoteData);

  int getInitData() {
    return _heavyTaskLocalData.getInitData();
  }
}
