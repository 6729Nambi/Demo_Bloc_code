import 'package:bloc_example/data/local/photo_local_data.dart';
import 'package:bloc_example/data/model/album.dart';
import 'package:bloc_example/data/remote/photo_remote_data.dart';
import 'package:bloc_example/infrastructure/api_core/result.dart';

class PhotoRepository {
  final PhotoRemoteData _photoRemoteData;
  final PhotoLocalData _photoLocalData;

  PhotoRepository(this._photoRemoteData, this._photoLocalData);

  Future<Result<Album>> getPhotoWithQuery(
    String query,
  ) async {
    /// Can return offline data first and then return data from API
    /// So user will see their previous data first or in offline mode data can
    /// be get from local DB
    return _photoRemoteData.getPhotoWithQuery(query);
  }
}
