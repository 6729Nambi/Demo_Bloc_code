class HeavyTaskRemoteData {
  int getInitData() {
    return 0;
  }
}
