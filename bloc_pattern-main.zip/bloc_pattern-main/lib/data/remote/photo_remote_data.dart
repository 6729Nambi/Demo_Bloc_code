import 'package:bloc_example/data/model/album.dart';
import 'package:bloc_example/infrastructure/api_core/api_core.dart';
import 'package:bloc_example/infrastructure/api_core/result.dart';
import 'package:bloc_example/infrastructure/photo_api/photo_api/photo_api.dart';

class PhotoRemoteData extends ApiCore {
  Future<Result<Album>> getPhotoWithQuery(
    String query,
  ) async {
    return safeCall(
      PhotoApi(await dio).getPhotoWithQuery(
        "domain/json;charset=UTF-8",
        query,
        {},
      ),
    );
  }
}
