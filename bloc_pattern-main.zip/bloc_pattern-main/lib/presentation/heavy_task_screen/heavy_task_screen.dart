import 'package:bloc_example/domain/bloc/firebase_analytic_bloc.dart';
import 'package:bloc_example/domain/bloc/heavy_task_bloc/heavy_task_bloc.dart';
import 'package:bloc_example/domain/bloc/heavy_task_bloc/heavy_task_state.dart';
import 'package:bloc_example/injector.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class HeavyTaskScreen extends StatefulWidget {
  const HeavyTaskScreen({Key? key}) : super(key: key);

  @override
  State<HeavyTaskScreen> createState() => _HeavyTaskScreenState();
}

class _HeavyTaskScreenState extends State<HeavyTaskScreen> {
  @override
  void initState() {
    super.initState();
    getIt<HeavyTaskBloc>().initHeavyTaskBloc();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Heavy Task"),
      ),
      body: BlocBuilder<HeavyTaskBloc, HeavyTaskState>(
        bloc: getIt<HeavyTaskBloc>(),
        builder: (context, state) {
          if (state is HeavyTaskInitState) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }

          if (state is HeavyTaskLoadedState) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("state ${state.count}"),
                  ElevatedButton(
                    onPressed: () {
                      getIt<HeavyTaskBloc>().increaseCount();
                    },
                    child: const Text(
                      "Increase",
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      getIt<HeavyTaskBloc>().decreaseCount();
                      getIt<FirebaseAnalyticBloc>().logEvent(
                        name: 'decrement_button',
                        parameters: {
                          "value": "$state",
                        },
                      );
                    },
                    child: const Text(
                      "Decrease",
                    ),
                  ),
                ],
              ),
            );
          }

          return const Text("No services");
        },
      ),
    );
  }
}
