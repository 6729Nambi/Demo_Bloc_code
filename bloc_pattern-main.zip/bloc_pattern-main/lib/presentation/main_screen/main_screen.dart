import 'package:auto_route/auto_route.dart';
import 'package:bloc_example/domain/bloc/counter_bloc/counter_bloc.dart';
import 'package:bloc_example/domain/bloc/firebase_analytic_bloc.dart';
import 'package:bloc_example/domain/bloc/firebase_remote_config_bloc.dart';
import 'package:bloc_example/injector.dart';
import 'package:bloc_example/presentation/route_config/app_router.gr.dart';
import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class MainScreen extends StatefulWidget {
  const MainScreen({Key? key}) : super(key: key);

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  @override
  Widget build(BuildContext context) {
    return BlocBuilder<CounterBloc, int>(
      bloc: getIt<CounterBloc>(),
      builder: (BuildContext context, state) {
        return Scaffold(
          appBar: AppBar(
            title: const Text("Bloc"),
          ),
          floatingActionButton: Align(
            alignment: getIt<FirebaseRemoteConfigBloc>().getButtonSide()
                ? Alignment.bottomLeft
                : Alignment.bottomRight,
            child: Padding(
              padding: const EdgeInsets.only(left: 32),
              child: FloatingActionButton(
                onPressed: () {},
                child: const Icon(Icons.add),
              ),
            ),
          ),
          body: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text("$state"),
                ElevatedButton(
                  key: const Key('button'),
                  onPressed: () {
                    getIt<CounterBloc>().increment();
                    getIt<FirebaseAnalyticBloc>().logEvent(
                      name: 'increment_button',
                      parameters: {
                        "value": "$state",
                      },
                    );
                  },
                  child: const Text(
                    "Click Me",
                  ),
                ),
                ElevatedButton(
                  onPressed: () {
                    AutoRouter.of(context).push(const Screen2());
                  },
                  child: const Text(
                    "Screen 2",
                  ),
                ),
                ElevatedButton(
                  key: const Key("photo_screen_button"),
                  onPressed: () {
                    AutoRouter.of(context).push(const PhotosScreen());
                  },
                  child: const Text(
                    "Photo Screen",
                  ),
                ),
                ElevatedButton(
                  onPressed: () async {
                    /// Firebase analytics event
                    FirebaseAnalytics.instance.logEvent(name: "testing");

                    /// Firebase Crashlytics
                    // throw Exception();
                  },
                  child: Text(
                    "${getIt<FirebaseRemoteConfigBloc>().getButtonSide()}",
                  ),
                )
              ],
            ),
          ),
        );
      },
    );
  }
}
