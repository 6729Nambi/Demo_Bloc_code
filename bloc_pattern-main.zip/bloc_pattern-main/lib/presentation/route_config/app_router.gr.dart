// **************************************************************************
// AutoRouteGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// AutoRouteGenerator
// **************************************************************************
//
// ignore_for_file: type=lint

import 'package:auto_route/auto_route.dart' as _i5;
import 'package:flutter/material.dart' as _i6;

import '../heavy_task_screen/heavy_task_screen.dart' as _i4;
import '../main_screen/main_screen.dart' as _i1;
import '../photos_screen/photos_screen.dart' as _i2;
import '../screen_2/screen_2.dart' as _i3;

class AppRouter extends _i5.RootStackRouter {
  AppRouter([_i6.GlobalKey<_i6.NavigatorState>? navigatorKey])
      : super(navigatorKey);

  @override
  final Map<String, _i5.PageFactory> pagesMap = {
    MainScreen.name: (routeData) {
      return _i5.MaterialPageX<dynamic>(
          routeData: routeData, child: const _i1.MainScreen());
    },
    PhotosScreen.name: (routeData) {
      return _i5.MaterialPageX<dynamic>(
          routeData: routeData, child: const _i2.PhotosScreen());
    },
    Screen2.name: (routeData) {
      return _i5.MaterialPageX<dynamic>(
          routeData: routeData, child: const _i3.Screen2());
    },
    HeavyTaskScreen.name: (routeData) {
      return _i5.MaterialPageX<dynamic>(
          routeData: routeData, child: const _i4.HeavyTaskScreen());
    }
  };

  @override
  List<_i5.RouteConfig> get routes => [
        _i5.RouteConfig(MainScreen.name, path: '/'),
        _i5.RouteConfig(PhotosScreen.name, path: '/photos-screen'),
        _i5.RouteConfig(Screen2.name, path: '/Screen2'),
        _i5.RouteConfig(HeavyTaskScreen.name, path: '/heavy-task-screen')
      ];
}

/// generated route for
/// [_i1.MainScreen]
class MainScreen extends _i5.PageRouteInfo<void> {
  const MainScreen() : super(MainScreen.name, path: '/');

  static const String name = 'MainScreen';
}

/// generated route for
/// [_i2.PhotosScreen]
class PhotosScreen extends _i5.PageRouteInfo<void> {
  const PhotosScreen() : super(PhotosScreen.name, path: '/photos-screen');

  static const String name = 'PhotosScreen';
}

/// generated route for
/// [_i3.Screen2]
class Screen2 extends _i5.PageRouteInfo<void> {
  const Screen2() : super(Screen2.name, path: '/Screen2');

  static const String name = 'Screen2';
}

/// generated route for
/// [_i4.HeavyTaskScreen]
class HeavyTaskScreen extends _i5.PageRouteInfo<void> {
  const HeavyTaskScreen()
      : super(HeavyTaskScreen.name, path: '/heavy-task-screen');

  static const String name = 'HeavyTaskScreen';
}
