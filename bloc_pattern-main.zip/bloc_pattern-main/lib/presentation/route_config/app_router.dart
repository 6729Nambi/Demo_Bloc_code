import 'package:auto_route/auto_route.dart';
import 'package:bloc_example/presentation/heavy_task_screen/heavy_task_screen.dart';
import 'package:bloc_example/presentation/main_screen/main_screen.dart';
import 'package:bloc_example/presentation/photos_screen/photos_screen.dart';
import 'package:bloc_example/presentation/screen_2/screen_2.dart';

@MaterialAutoRouter(
  replaceInRouteName: 'Page,Route',
  routes: <AutoRoute>[
    AutoRoute(page: MainScreen, initial: true),
    AutoRoute(page: PhotosScreen),
    AutoRoute(page: Screen2),
    AutoRoute(page: HeavyTaskScreen),
  ],
)
class $AppRouter {}
