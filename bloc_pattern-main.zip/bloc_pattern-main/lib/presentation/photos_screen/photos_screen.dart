import 'package:bloc_example/data/model/album.dart';
import 'package:bloc_example/domain/bloc/photo_bloc/photo_bloc.dart';
import 'package:bloc_example/domain/bloc/photo_bloc/photo_state.dart';
import 'package:bloc_example/injector.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class PhotosScreen extends StatefulWidget {
  const PhotosScreen({Key? key}) : super(key: key);

  @override
  State<PhotosScreen> createState() => _PhotosScreenState();
}

class _PhotosScreenState extends State<PhotosScreen> {
  @override
  void initState() {
    super.initState();
    getIt<PhotoBloc>().getPhotoWithQuery(isFirstTime: true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Photo Screen"),
      ),
      body: BlocBuilder<PhotoBloc, PhotoState>(
        bloc: getIt<PhotoBloc>(),
        builder: (context, state) {
          if (state is PhotoInitState) {
            return const Center(child: CircularProgressIndicator());
          }
          if (state is PhotoLoadedState) {
            return GridView.builder(
              key: const Key("photo_grid_view"),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
              ),
              itemCount: state.photos.length,
              itemBuilder: (BuildContext context, int index) {
                Photo photo = state.photos[index];

                return Card(
                  child: SizedBox(
                    height: 100,
                    width: 100,
                    child: Image.network(photo.src.small),
                  ),
                );
              },
            );
          }
          return Container();
        },
      ),
    );
  }
}
