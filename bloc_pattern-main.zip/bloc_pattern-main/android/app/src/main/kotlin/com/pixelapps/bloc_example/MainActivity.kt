package com.pixelapps.bloc_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
